#include <iostream>
#include <cstdio>
#include <vector>
using std::pair;
using std::string;
using std::vector;
using std::min;
extern int mode_type, exit_flag, changed, read_only, tranc_flag;
extern vector <string> text;
extern string File_name;
