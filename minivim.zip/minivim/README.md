~~~~
This is minivim by andyc_03.
~~~~
This minivim has three modes: normal mode, insert mode, command mode.
## Normal mode
We can use $\uparrow \downarrow \leftarrow \rightarrow $ to move the cursor.
Moreover, we have Shortcut Keys, "dd","0","$","w,"b".

## Insert mode
You can edit the text.
Moreover, we have Word completition by pressing tab button(If you indeed want to press 4 space, just press tab twice).

## Command mode
Commands like ":w",":q",":q!",":wq" are accomplished.
Specifically, if you are in the Read-Only mode you should add "!" to override this mode(once ! is added, the Read-Only is overrided forever).

Extensions:
Word Completion 
Line Number and Jump 
Command History 
Path and relative path 